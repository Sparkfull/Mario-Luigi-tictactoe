package com.example.sparkfull.tictactoe;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // 0 = empty, 1 = Mario, 2 = Luigi
    int[] gameState = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    int activePlayer = 1;
    boolean gameActive = true;

    int[][] winningPositions = {{0,1,2}, {3,4,5}, {6,7,8}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};

    // Square onClick
    public void jumpIn(View view) {
        // "(ImageView) view" == itself
        ImageView square = (ImageView) view;

        // Grabs square tag and changes gameState to the active player
        int tappedSquare = Integer.parseInt(square.getTag().toString());

        // Check if square is empty first
        if (gameState[tappedSquare] == 0 && gameActive) {
            // Log active player into gameState according to tapped square
            gameState[tappedSquare] = activePlayer;

            // Check who is the active player and set their image
            if (activePlayer == 1) {
                square.setImageResource(R.drawable.mario);
                activePlayer = 2;
            } else if (activePlayer == 2) {
                square.setImageResource(R.drawable.luigi);
                activePlayer = 1;
            }

            // Animate squares
            square.setTranslationY(1500);
            square.animate().translationYBy(-1500).setDuration(300);

            // Looping through all winning positions
            for (int[] winningPosition : winningPositions) {
                if (gameState[winningPosition[0]] == gameState[winningPosition[1]] && gameState[winningPosition[1]] == gameState[winningPosition[2]] && gameState[winningPosition[0]] != 0) {

                    //Someone has won! 2: Mario & 1: Luigi because of the active player check switch
                    String winner = "";
                    if (activePlayer == 2) {
                        winner = "Mario!";
                    } else if (activePlayer == 1) {
                        winner = "Luigi!";
                    }

                    Toast.makeText(this, "The winner is " + winner, Toast.LENGTH_SHORT).show();

                    // Lock up game
                    gameActive = false;

                    // Display winner and "play again" button
                    TextView winnerText = findViewById(R.id.winnerTextView);
                    Button resetButton = findViewById(R.id.resetButton);

                    winnerText.setText("The winner is " + winner);
                    winnerText.setVisibility(View.VISIBLE);
                    resetButton.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    // Reset button onClick
    public void resetGame(View view) {
        TextView winnerText = findViewById(R.id.winnerTextView);
        Button resetButton = findViewById(R.id.resetButton);
        //GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);

        winnerText.setVisibility(View.INVISIBLE);
        resetButton.setVisibility(View.INVISIBLE);

        Toast.makeText(this, "test", Toast.LENGTH_SHORT).show();

        /*for (int i = 0; i < gridLayout.getChildCount(); i++) {
            ImageView square = (ImageView) gridLayout.getChildAt(i);
            square.setImageDrawable(null);
        }*/

        // Reset game states
        for (int x = 0; x < gameState.length; x++) {
            gameState[x] = 0;
        }
        activePlayer = 1;
        gameActive = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
